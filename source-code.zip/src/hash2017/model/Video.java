package hash2017.model;

public class Video {
	public int id;
	public int size;

	public Video(int id, int size) {
		this.id = id;
		this.size = size;
	}

}
